/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drunkgaugefx;

import drunkgaugecode.MyConnection;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author a154658
 */
public class LoginController implements Initializable {
    
    @FXML
    private Label lblusuario;
    private Label lblsenha;
    private TextField txtusuario;
    private PasswordField txtsenha;
    private Button btnentrar;
    private Hyperlink lkcadastro;
    private Hyperlink lksenha;
 
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
            Parent parent = FXMLLoader.load(getClass().getResource("/drunkgaugefx/Inicio.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(parent);
            stage.setScene(scene);
            stage.setTitle("DrunkGauge");
            stage.show();
    }
    
    @FXML
    private void handleCadastro(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
        Parent parent = FXMLLoader.load(getClass().getResource("/drunkgaugefx/Casdastrar.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.setTitle("Cadastrar");
        stage.show();
                
    }
    
    @FXML
    private void handleSenha(ActionEvent event) throws IOException {
        ((Node) (event.getSource())).getScene().getWindow().hide();
        Parent parent = FXMLLoader.load(getClass().getResource("/drunkgaugefx/Esqueceu.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(parent);
        stage.setScene(scene);
        stage.setTitle("Esqueci Senha");
        stage.show();
                
    }
    
    private void hide(){
    
    }
    
    private int acessarSistema(){
        
        try{
            MyConnection myConnection = new MyConnection();
            myConnection.statement = myConnection.connection.createStatement();
            String sql = "SELECT COUNT(*) FROM user WHERE user=" + txtusuario.getText() + " AND " + txtsenha.getText() ;
            myConnection.result = myConnection.statement.executeQuery(sql);
            
            JOptionPane.showMessageDialog(null, myConnection.result);
            
        }
        catch (ClassNotFoundException | SQLException e){
            System.out.println("Não conectado");
        }
        return 0;
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }    
    
}
